# Bien dau vao cho Lab 16 - luong CPU / LightGBM
# Terraform tu dong doc file ten "terraform.tfvars" trong cung thu muc.

project_id = "mystic-gradient-505507-g3"

# Cac bien duoi day de mac dinh trong variables.tf, liet ke ra cho de doc:
# region       = "us-central1"
# zone         = "us-central1-a"
# machine_type = "e2-medium"
# gpu_count    = 0            # 0 = CPU-only (LightGBM). Doi thanh 1 neu lam Phu luc GPU.
